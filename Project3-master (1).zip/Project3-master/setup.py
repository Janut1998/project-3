from setuptools import setup, find_packages

setup(name="calc", packages=find_packages())